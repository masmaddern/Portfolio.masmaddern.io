#!/usr/bin/python
import json
from bson import json_util
from bson.json_util import dumps
import bottle
from bottle import route, run, request, abort
#imports for database
from pymongo import MongoClient
connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

# URI paths for restfull services
#
#
   #UPDATING OUR STOCK BY PROVIDING THE CRITERIA, WE USE METHOD PUT, When Key Value is Specified
#
@route('/update/<TickerValue>', method='PUT')
def UpdateMyStock(TickerValue):
  jsondata = request.json #Retrive all the data passed in the url
  query = { "Ticker" : TickerValue} #Query Used To Search Documents For Updating
 
  #We use a loop to update the Colection using the parameters from the url
  for key in jsondata:
    update =  { "$set":{key:jsondata[key]}}
    #updating collection
    collection.update(query,update)
  updateDocs = collection.find({"Ticker":TickerValue})
  line = "--" * 45 +"\n" #this will print a line
  result = dumps(updateDocs) #
  return line+"\n   All These Details Got Updated>>  \n"+str(result)+"\n  End Of Document >> \n"+line

   
  
# We would wish to add document to our stock colection
# we use put

##when no parameter is added, we still add the object to the collection
##---------------------------------------No Ticker Value Added----------------------------------------
#
@route('/addDocument', method='POST')
def addDocumentStock():
  #get all passed dat in a json object using the request.json
  jsonData = request.json
  #Lets insert the document passed to the collection
  newDocument = collection.insert(jsonData) #returns the _id
  retriveDoc = collection.find_one({"_id":newDocument})
  line = "--" * 45 +"\n"
  return line+ "\nAdded Document >> \n "+dumps(retriveDoc)+"\n End Of Document >>\n "+line #return inserted document.

##-----------------------------When Ticker Value Is Added --------------------------------------------
@route('/addDocument/<tickerValue>', method='POST')
def addDocumentStock(tickerValue):
  #get all passed dat in a json object using the request.json
  jsonData = request.json
  jsonData.update( {'Ticker' : tickerValue} ) 
  #Lets insert the document passed to the collection
  recordId = collection.insert(jsonData) #insert data to the stocks collection
  retriveDoc = collection.find_one({"_id":recordId})
  line = "--" * 45 +"\n"
  return line+ "\nAdded Document>> \n "+dumps(retriveDoc)+" \n End Of Document >>\n "+line #return inserted document.




##---------------------------------------Deleting Data --------------------------------------------------------------
#

@route('/remove/<TickerValue>', method='GET')
def removeStock(TickerValue):
  query = {"Ticker" :TickerValue} #Query to Search Target Data
  result = collection.delete_many(query) #Will delete all documents that matching the query
  return "\n Requested Document Has Been Deleted.... \n" #return results to the user.



##-----------------------------Reading Data From Collectiosn Given Ticker Value-------------------------------------------

@route('/RequestDoc/<TickerValue>', method='GET')
def requestDocument(TickerValue):
  readDocument = collection.find({"Ticker":TickerValue}) #
  #provided
  line = "--" * 45 +"\n"
  return line+"\nCreteria Added [Ticker Value] \n This Is The Requested Document >>\n "+dumps(readDocument)+" \n End Of Requested Document >>"

#When no parameter is added

@route('/RequestDoc/', method='GET')
def requestDocument():
  readDocument = collection.find().limit(1) #First Records Will Displayed
  #provided
  line = "--" * 45 +"\n"
  return line+"\n No Creteria Added [Ticker Value]\n This Is The Requested Document >>\n "+dumps(readDocument)+" \n End Of Requested Document >>\n"


##-----------------------------Getting A Stock Report--------------------------------------


@route('/stockSummery/', method='POST')
def getReport(): 
  line = "--" * 45 +"\n"
  tickerSymbols = request.json.get('list') #retrieves the value of the list key in the url data
  #Removing the curl Braces from the List 
  tickerSymbols = tickerSymbols.replace("[","")
  tickerSymbols = tickerSymbols.replace("]","")
  tickerSymbols = list(tickerSymbols.split(",")) #create a list from the remaining list
  EmptyTickers = list()
  print(tickerSymbols)
  underline = "_" * 30;
  #This for loop uses each ticker in the list,
  #get ist summer and add the summery to the items list
  for ticker in tickerSymbols:
      item = Pipeline(ticker)
      print(item)
      #Building string for display
      EmptyTickers.append(line+" \t\t\t **Report For Symbol ["+ticker+"] ** \n \t\t\t"+underline+" \n"+item+"\n\n "+line)
  return EmptyTickers  #return a lit of items


##-----------------------------Getting Industry Report--------------------------------------
#
#
#
#

#Most URLs replaces spaces with +, therefore for an industry 
#That has spaces, we replace the spaces with + sign
@route('/getIndustryReport/<industryName>', method='GET')
def getReport(industryName):
  industry = industryName.replace("+"," ")
  #Pipeline is composed of Stages, each stage 
  #Stage One In The Pipeline, Fields To Be Produces
  print("\n\n\n "+industry+"\n\n")
  result2 = IndustryPipeline(industry)
  firstStage = { '$project': {'Industry':1, 'Ticker':1,'Float Short':1,'Relative Volume':1,'Volume':1,'Performance (Year)':1 } }
  #Second Stage
  secondStage = { '$match': { "Industry": industry } }
  print("\n\n\n "+str(secondStage)+"\n\n")
  #Stage Three
  thirsStage = { '$group': { '_id': "$Industry", 'Total Float Short': {'$sum': "$Float Short" },
                           'Average Relative Volume':{'$avg':"$Relative Volume"},
                           'Average Volume':{'$avg':'$Volume'},
                           'Max Performance (Year)':{'$max':'$Performance (Year)'},
                           'Total Volume':{'$sum':'$Volume'} } }
  #Adding Limit
  fourthStage = { '$limit' : 5 }
  query = [firstStage,secondStage,thirsStage,fourthStage]
  print(str(query))
  result=collection.aggregate(query)
  result = dumps(result)
  #print results to user.
  return "-------- \n \t\t\t Portfolio Report For  ["+industry+"] Industrie(s) \n\n "+result+" \n-------- \n"+result2+"\n"

##************************************************End Of Industry Report *****************************************
#
#

#--------------------------Pipeline -------------------------------------------------------------------------------
#
#
#
#
#This pipeline retrive data depending on several specified data
#we sum fields, calculate Voume, 

def Pipeline(ticker):
  #stage one specifies the fields to be passed to the next stages
  firstStage = { '$project': { 'Ticker':1,'Float Short':1,'Relative Volume':1,'Volume':1,'Performance (Year)':1 } }
  #Specifies the query [$match] << The Targeted Documents
  #
  secondStage = { '$match': { "Ticker": ticker } }
  #We do all The Operations Here sum, Divion, Multiplication and Others
  thirdStage = { '$group': { '_id': "$Ticker", 'Total Float Short': {'$sum': "$Float Short" },
                           'Average Relative Volume':{'$avg':"$Relative Volume"},
                           'Total Accupied Volume':{'$sum':'$Volume'},
                           'Max Performance (Year)':{'$max':'$Performance (Year)'},
                           'Minimum Volume Used':{'$min':'$Volume'} } }
  myQuery = [firstStage,secondStage,thirdStage]
  result=collection.aggregate(myQuery) 
  result = dumps(result)
  return result



def IndustryPipeline(industry):
  #stage one specifies the fields to be passed to the next stages
  firstStage = { '$project': { 'Industry':1,'Float Short':1,'Price':1,'Average True Range':1,'50-Day Simple Moving Average':1,'Change':1 } }
  #Specifies the query [$match] << The Targeted Documents
  #
  secondStage = { '$match': { "Industry": industry } }
  #We do all The Operations Here sum, Divion, Multiplication and Others
  thirdStage = { '$group': { '_id': "$Industry", 'Total Float Short': {'$sum': "$Float Short" },
                           'Average Average True Range':{'$avg':"$Average True Range"},
                           'Total Price':{'$sum':'$Price'},
                           'Max 50-Day Simple Moving Average (Year)':{'$max':'$50-Day Simple Moving Average'},
                           'Minimum Change':{'$min':'$Change'} } }
  
  #Adding Limit
  fourthStage = { '$limit' : 5 }
  myQuery = [firstStage,secondStage,thirdStage,fourthStage]
  result=collection.aggregate(myQuery) 
  result = dumps(result)
  return "-------- \n More Usefull Information \n\n"+result+"\n\n"

#--------------------------Main Program Start ----------------------------------------------------
#
#
#
#
  
if __name__ == '__main__':
  run(debug=True,reloader = True)
  #run(host='localhost', port=8080)