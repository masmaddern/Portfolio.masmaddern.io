import json
from bson import json_util
from pymongo import MongoClient
connection = MongoClient('localhost', 27017)
database = connection['market']
collection = database['stocks']

def insertDocument(document):
  message = ""
  try:
    result=collection.insert(document)
    message = "Document Added Successifully"
  except ValidationError as ve:
    abort(400, str(ve))
    message = "Document Could Not Be Added.."
  return message

def main():
  line = "--" * 45  
  print(line+"\n\n")
  document = raw_input("Enter Your Document:")
  print("Processing Document.....\n Received Document \n"+line)
  print(document)
  print insertDocument(json.loads(document))
  print("Thank you for using Our Service....Byee \n")
  print(line+"\n\n")
  
main()