import json
from bson import json_util
from bson.json_util import dumps
from pymongo import MongoClient
connection = MongoClient('localhost', 27017)
database = connection['market']
collection = database['stocks']

def updateDocument(query,update):
  try:
    line = "--" * 50  
    collection.update_many(query,update)
    result=collection.find(query,{"Current Ratio":1,"Ticker":1,"Total Debt/Equity":1,"Volume":1}).limit(10)
    print("\t\t RESULTS (First Ten Results)");
    print("--" * 50)
    print(dumps(result))
    print(line+"\n\n")
  except ValidationError as ve:
    abort(400, str(ve))
  

def main():
  line = "--" * 45  
  print(line+"\n\n")
  print("\t\t Provide The Ticker Value for The Documents To Be Updated, All Documents With\n\t\t That Ticker Value Will Be Changed \n");
  print(line+"\n")
  tvalue = raw_input("Enter Ticker Value# ")
  print("Received >>"+tvalue);
  print(">> The First Ten Results are Displayed Below");
  query = {"Ticker" : tvalue}
  result=collection.find(query,{"Current Ratio":1,"Ticker":1,"Total Debt/Equity":1,"Volume":1}).limit(10)
  print(dumps(result))
  
  print(line+"\n")
  
  
  print("Lets  Change Volume Value Of These Documents \n")
  volume = float(raw_input("New Volume#"))
  
  print("Thank you, We are Processing Your Request....")
  print(line+"\n")
  
  
  update =  { "$set":{"Volume":volume}}
  updateDocument(query,update)
  
main()