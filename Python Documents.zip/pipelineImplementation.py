import json
from bson import json_util
from bson.json_util import dumps
from pymongo import MongoClient
connection = MongoClient('localhost', 27017)
database = connection['market']
collection = database['stocks']

def pipeline(pipe):
  try:
    line = "--" * 45  
    print(line+"\n")
    result=collection.aggregate(pipe)
    result = dumps(result)
    print(result)
    print(line+"\n")
  except ValidationError as ve:
    abort(400, str(ve))
  

def main():
  line = "--" * 45  
  print("\t\t Welcome, Lets Use Pipeline ")
  print("\t\t You will need to Enter Sector Name \n");
  print(line+"\n")
  sectorname = raw_input("Name Of The Sector# ")
  #I will add each stage separetly in the next query
  firstStage = { '$match': { "Sector": sectorname } }
  secondStage= { '$group': { '_id': "$Industry", 'Total Austanding Shares:': {'$sum': "$Shares Outstanding" } } }
  pipe = [firstStage,secondStage]
  pipeline(pipe)
  print("Thank You, We are Processing..\n")
main()